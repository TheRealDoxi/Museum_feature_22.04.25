  // Vent i 3 sekunder og gå derefter videre til næste side

  setTimeout(function () {
    window.location.href = "index.html"; // Skift til den ønskede HTML-side
  }, 3000);

  